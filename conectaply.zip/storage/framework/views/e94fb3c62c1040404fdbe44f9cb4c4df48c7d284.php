<?php $__env->startSection('title','Facturacion'); ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="  p-10">

        <table class="min-w-full leading-normal ">
            <thead>
                <tr>
                    <th
                        class="px-5 py-3 border-b-2 border-gray-200 bg-white text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                        Total
                    </th>
                    <th
                        class="px-5 py-3 border-b-2 border-gray-200 bg-white text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                        divisa
                    </th>

                    <th
                        class="px-5 py-3 border-b-2 border-gray-200 bg-white text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                        Estado
                    </th>
                    <th class="px-5 py-3 border-b-2 border-gray-200 bg-white text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                        Ver
                    </th>
                    <th class="px-5 py-3 border-b-2 border-gray-200 bg-white text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                        Descargar
                    </th>
                    <th
                        class="px-5 py-3 border-b-2 border-gray-200 bg-white text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                        creado
                    </th>
                    <th
                        class="px-5 py-3 border-b-2 border-gray-200 bg-white text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                        Finaliza
                    </th>
                </tr>
            </thead>
            <tbody>


                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <tr>
                        <td class="p-5 m-5">
                            <span class="capitalize"><?php echo e(($invoice->amount_paid/100)); ?>.00 </span>
                        </td>
                        <td class="p-5 m-5">
                            <span class="capitalize"><?php echo e($invoice->currency); ?></span>
                        </td>

                        <td class="p-5 m-5">
                            <span class="capitalize"><?php echo e($invoice->status); ?></span>
                        </td>

                        <td class="p-5 m-5">
                            <span class="capitalize"><a href="<?php echo e($invoice->hosted_invoice_url); ?>" target="blank_">Visualizar</a></span>
                        </td>
                        <td class="p-5 m-5">
                            <span class="capitalize"><a href="<?php echo e($invoice->invoice_pdf); ?>">Descargar</a></span>
                        </td>
                        <td class="p-5 m-5">
                            <span class="capitalize">Aun no</span>
                        </td>
                        <td class="p-5 m-5">
                            <span class="capitalize">Aun tampoco</span>
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>

    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/u214103417/domains/socialsystemsconnect.com/public_html/conexioneleven/resources/views/stripe/facturacion.blade.php ENDPATH**/ ?>