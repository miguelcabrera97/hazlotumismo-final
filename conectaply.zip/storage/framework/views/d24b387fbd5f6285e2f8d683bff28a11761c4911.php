<?php $__env->startSection('title','Crear Sitio'); ?>
    

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="z-0 grid grid-cols-1 md:grid-cols-2  lg:grid-cols-3 xl:grid-cols-4 p-10 gap-6">
           
        <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
         <div class="border border-gray-200 grid grid-cols-1  mt-3 h-4/6" id="template_list">
            <div class="flex  flex-col"> 
                  
                 <div class="h-full w-full relative ">
                     
                     <div class="  absolute rounded-b-2xl  backdrop-blur-sm bg-black/50 h-full w-full opacity-0 hover:opacity-100 hover:ease-all hover:duration-300 ">
                         <div class="grid grid-cols-1 gap-1 justify-items-center" style="padding-top: 45%" >

                           
                           
                           <div class="flex items-center justify-center h-full">
                            <button class="py-2 px-4 bg-fuchsia-500 text-white rounded hover:bg-fuchsia-700" onclick="toggleModal(<?php echo e($template->template_id); ?>)">Empezar a Crear</button>
                          </div>
                           
                           
                            
                            <a class="w-3/5 m-2  items-center p-3 text-md text-center text-white rounded-lg hover:underline-offset-8 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 hover:underline" target="_blank" href="<?php echo e($template->preview_url); ?>">Vista Previa</a>
                            
                         </div>  
                     </div>
                      
                     
                     
                     <div class=" bg-cover bg-center  h-full w-full opacity-1 bg-white" >
                         <img class="rounded-t-3xl " src="<?php echo e($template->desktop_thumbnail_url); ?>" alt="Imagen-Fondo" border="0">
                     </div>
                     
                     
                 </div>
                 <div class="rounded-b-2xl bg-white w-full text-center  py-2"> 
                    <p class="text-sm capitalize"><?php echo e($template->template_name); ?></p>    
                 </div>
              </div>
         </div>
                     
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         

    </div>

    <div class="fixed z-10 overflow-y-auto top-0 w-full left-0 hidden" id="modal">
        <div class="flex items-center justify-center min-height-100vh pt-4 px-4 pb-20 text-center sm:block sm:p-0">
          <div class="fixed inset-0 transition-opacity">
            <div class="absolute inset-0 bg-gray-900 opacity-75" />
          </div>
          <span class="hidden sm:inline-block sm:align-middle sm:h-screen">&#8203;</span>
          <div class="inline-block align-center bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full" role="dialog" aria-modal="true" aria-labelledby="modal-headline">
            <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
              <label> Nombre del sitio</label>
              <form action="<?php echo e(route('crear')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                 <input type="text" class="w-full bg-gray-100 p-2 mt-2 mb-3" name="nombre" id="nombresite" />
                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <br>
                  <small><?php echo e($message); ?></small>
                  <br>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 <input type="hidden" class="w-full bg-gray-100 p-2 mt-2 mb-3" name="template_id" id="templateid"/>
                 <input type="hidden" class="w-full bg-gray-100 p-2 mt-2 mb-3" name="user" id="emailuser" value="<?php echo e(Auth::user()->email); ?>" /> 
                 <button type="button" class="m-2 items-center p-3 text-md text-center font-bold bg-gray-500 text-white rounded hover:bg-gray-700 mr-2" onclick="toggleModal()"><i class="fas fa-times"></i> Cancelar</button>
                 <input type="submit" id="CrearSitio" class="m-2  items-center p-3 text-md text-center font-bold text-white bg-fuchsia-500 hover:bg-fuchsia-400 rounded-lg dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800" value="Crear mi Sitio" >
              </form>
            </div>
          </div>
        </div>
      </div>

  <script>
   function toggleModal(id) {
        document.getElementById('modal').classList.toggle('hidden')
        document.getElementById("templateid").value = id;
    }
    
  </script>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/js/script.js']); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\hazlotumismo-final\resources\views/templates.blade.php ENDPATH**/ ?>