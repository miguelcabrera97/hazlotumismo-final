@section('title','Inicio')
<x-app-layout>
    <div class="  p-10">
        
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-9">
            <div class="relative hover:scale-110 transition duration-200 bg-blue-200 p-6 h-60 rounded-lg shadow-sm text-center  inline-block align-middle">01</div>
            <div class="relative hover:scale-110 transition duration-200 bg-blue-200 p-6 h-60 rounded-lg shadow-sm">Pto Bob 02</div>
            <div class="relative hover:scale-110 transition duration-200 bg-blue-200 p-6 h-60 rounded-lg shadow-sm">Pto Bob 03</div>
            <div class="relative hover:scale-110 transition duration-200 bg-blue-200 p-6 h-60 rounded-lg shadow-sm">Pto Bob 04</div>
            <div class="relative hover:scale-110 transition duration-200 bg-blue-200 p-6 h-60 rounded-lg shadow-sm">Pto Bob 05</div>
            <div class="relative hover:scale-110 transition duration-200 bg-blue-200 p-6 h-60 rounded-lg shadow-sm">Pto Bob 06</div>
        </div>
    </div>

    
</x-app-layout>
